from random import randint

src = [randint(-100, 100) for _ in range(30)]
print(f'Source list: {src}')
maxint = max(src)
print('Max item: {} by the index of {}'.format(maxint, src.index(maxint)))
for i in range((len(src) // 2) - 1):
    if src[i] < 0 and src[i + 1] < 0:
        print(src[i], src[i + 1])
